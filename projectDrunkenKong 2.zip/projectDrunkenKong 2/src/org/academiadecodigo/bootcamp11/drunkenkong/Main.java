package org.academiadecodigo.bootcamp11.drunkenkong;

/**
 * Created by codecadet on 09/10/17.
 */
public class Main {

    public static void main(String[] args) throws InterruptedException {

        Game game = new Game();
        game.init();
        game.start();


    }

}
