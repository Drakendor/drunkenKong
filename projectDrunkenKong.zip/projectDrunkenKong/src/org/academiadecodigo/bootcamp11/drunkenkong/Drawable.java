package org.academiadecodigo.bootcamp11.drunkenkong;

/**
 * Created by codecadet on 09/10/17.
 */
public interface Drawable {

    void draw();
    void hide();
}
