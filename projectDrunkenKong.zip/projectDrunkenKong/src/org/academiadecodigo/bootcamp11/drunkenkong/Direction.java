package org.academiadecodigo.bootcamp11.drunkenkong;

public enum Direction {
    LEFT,
    RIGHT,
    UP,
    DOWN,
    JUMP;
}
